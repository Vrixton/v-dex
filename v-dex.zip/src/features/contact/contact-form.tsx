"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";

import { useSound } from "@/components/sound/use-sound";
import { useToast } from "@/components/toast/toast-context";
import { Badge } from "@/components/ui/badge";
import { BracketFrame } from "@/components/ui/bracket-frame";
import { Button } from "@/components/ui/button";
import { format } from "@/i18n/format";
import { useMessages } from "@/i18n/locale-provider";
import {
  hasErrors,
  validateContact,
  LIMITS,
  type ContactErrorCode,
  type ContactErrors,
  type ContactField,
} from "@/lib/contact-schema";

import type { TransmissionStatus } from "./transmission-status";

const TEXT_FIELDS = [
  { name: "name", type: "text" },
  { name: "email", type: "email" },
] as const;

const FIELD_ORDER: readonly ContactField[] = ["name", "email", "message"];

export function ContactForm({
  onStatusChange,
}: {
  onStatusChange?: (status: TransmissionStatus) => void;
}) {
  const play = useSound();
  const toast = useToast();
  const m = useMessages().contact.form;
  const [status, setLocalStatus] = useState<TransmissionStatus>("idle");
  const [errors, setErrors] = useState<ContactErrors>({});
  const startedAt = useRef(0);

  function setStatus(next: TransmissionStatus) {
    setLocalStatus(next);
    onStatusChange?.(next);
  }

  function errorText(field: ContactField, code: ContactErrorCode): string {
    const limits = field === "email" ? { min: 0, max: 0 } : LIMITS[field];
    return format(m.errors[code], limits);
  }

  useEffect(() => {
    startedAt.current = Date.now();
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const form = event.currentTarget;
    const data = new FormData(form);
    const input = {
      name: String(data.get("name") ?? ""),
      email: String(data.get("email") ?? ""),
      message: String(data.get("message") ?? ""),
      website: String(data.get("ref_token") ?? ""),
      startedAt: startedAt.current,
    };

    const found = validateContact(input);
    setErrors(found);

    if (hasErrors(found)) {
      play("error");
      toast({ label: m.toastLabel, value: m.toasts.invalid, tone: "warning", key: "contact" });
      const firstInvalid = FIELD_ORDER.find((key) => found[key]);
      if (firstInvalid) {
        form.querySelector<HTMLElement>(`[name="${firstInvalid}"]`)?.focus();
      }
      return;
    }

    setStatus("sending");

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(input),
      });

      if (response.status === 429) {
        setStatus("limited");
        play("error");
        toast({ label: m.toastLabel, value: m.toasts.limited, tone: "warning", key: "contact" });
        return;
      }

      if (!response.ok) throw new Error("send failed");

      setStatus("sent");
      play("select");
      toast({ label: m.toastLabel, value: m.toasts.sent, tone: "success", key: "contact" });
      form.reset();
      startedAt.current = Date.now();
    } catch {
      setStatus("failed");
      play("error");
      toast({ label: m.toastLabel, value: m.toasts.failed, tone: "error", key: "contact" });
    }
  }

  function resetStatus() {
    if (status === "sent" || status === "failed") setStatus("idle");
  }

  const sending = status === "sending";

  return (
    <section className="relative flex flex-col gap-5 rounded-panel bg-surface p-5 md:p-8">
      <BracketFrame className="-inset-2 text-brand-cyan" />

      <header className="flex items-center justify-between gap-3">
        <h2 className="text-sm text-fg md:text-base">
          {m.title}{" "}
          <span className="hidden text-xs text-fg-muted sm:inline md:text-sm">|| {m.subtitle}</span>
        </h2>
        <Badge tone="yellow">{`[${m.responseLabel}]: <24h`}</Badge>
      </header>
      {status === "limited" ? (
        <div className="mt-4 flex flex-col items-center gap-3 rounded-control bg-terminal p-5 text-center">
          <p className="text-sm text-fg-muted">{`[${m.saturated.label}]: ${m.saturated.value}`}</p>
          <span
            aria-hidden="true"
            className="mt-5 block h-16 w-32 bg-[url('/link-unplugged.webp')] bg-contain bg-no-repeat"
            style={{ imageRendering: "pixelated" }}
          />
          <p className="mt-3 text-xs leading-relaxed text-fg-muted md:text-sm">
            {m.saturated.body}
          </p>
        </div>
      ) : (
        <>
          <p className="text-[10px] text-fg-muted md:text-xs">{m.intro}</p>
          <form onSubmit={handleSubmit} noValidate className="mt-4 flex flex-col gap-4">
            <input
              type="text"
              name="ref_token"
              tabIndex={-1}
              autoComplete="off"
              aria-hidden="true"
              className="absolute size-0 opacity-0"
            />

            {TEXT_FIELDS.map((field) => (
              <label key={field.name} className="flex flex-col gap-1.5">
                <span className="flex items-baseline justify-between gap-2">
                  <span className="text-xs text-brand-cyan/70 md:text-sm">
                    {`[${m.fields[field.name].label}]:`}
                  </span>
                  {errors[field.name] ? (
                    <span
                      id={`${field.name}-error`}
                      className="text-[10px] text-fg-danger md:text-xs"
                    >
                      {errorText(field.name, errors[field.name]!)}
                    </span>
                  ) : null}
                </span>

                <span className="flex items-center gap-2 rounded-control border border-transparent bg-terminal px-3 py-2.5 transition-colors focus-within:border-brand-cyan">
                  <span aria-hidden="true" className="shrink-0 text-xs text-status-ok">
                    {">_"}
                  </span>
                  <input
                    name={field.name}
                    type={field.type}
                    placeholder={m.fields[field.name].placeholder}
                    onFocus={() => {
                      play("hover");
                      resetStatus();
                    }}
                    aria-invalid={Boolean(errors[field.name])}
                    aria-describedby={errors[field.name] ? `${field.name}-error` : undefined}
                    className="w-full bg-transparent text-xs text-fg outline-none placeholder:text-fg-muted/60 md:text-sm"
                  />
                </span>
              </label>
            ))}

            <label className="flex flex-col gap-1.5">
              <span className="flex items-baseline justify-between gap-2">
                <span className="text-xs text-brand-cyan/70 md:text-sm">
                  {`[${m.fields.message.label}]:`}
                </span>
                {errors.message ? (
                  <span id="message-error" className="text-[10px] text-fg-danger md:text-xs">
                    {errorText("message", errors.message)}
                  </span>
                ) : null}
              </span>

              <span className="flex gap-2 rounded-control border border-transparent bg-terminal px-3 py-2.5 transition-colors focus-within:border-brand-cyan">
                <span aria-hidden="true" className="shrink-0 text-xs text-status-ok">
                  {">_"}
                </span>
                <textarea
                  name="message"
                  rows={5}
                  placeholder={m.fields.message.placeholder}
                  onFocus={() => {
                    play("hover");
                    resetStatus();
                  }}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? "message-error" : undefined}
                  className="w-full resize-none bg-transparent text-xs text-fg outline-none placeholder:text-fg-muted/60 md:text-sm"
                />
              </span>
            </label>

            <Button type="submit" size="lg" disabled={sending} sound={false}>
              <span className="relative">{sending ? m.submitting : m.submit}</span>
            </Button>
          </form>
        </>
      )}
    </section>
  );
}
